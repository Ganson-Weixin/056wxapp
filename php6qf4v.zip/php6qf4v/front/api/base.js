﻿const base = {
    url : "http://localhost:8080/php6qf4v/"
}
export default base
